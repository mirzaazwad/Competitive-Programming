/* Write a program that uses printf to display
 * the following picture on the screen: 
 *        *
 *       *
 *      *
 * *   *
 *  * *
 *   *
 */
#include <stdio.h>

int main(void)
{
    printf("\n       *\n");
    printf("      * \n");
    printf("     *  \n");
    printf("*   *   \n");
    printf(" * *    \n");
    printf("  *     \n\n");

    return 0;
}
