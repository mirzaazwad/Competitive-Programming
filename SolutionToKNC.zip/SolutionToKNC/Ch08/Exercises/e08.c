/* Write a declaration for a two-dimensional array named temperature_readings that
 * stores one month of hourly temperature readings. (For simplicity, assume that
 * a month has 30 days.) The rows of the array should represent days of the month;
 * the columns should represent hours of the day.
 */

/* Answer: */
int temperature_readings[30][24];
