/* Modify the find_middle function of 11.5 so that it uses pointer arithmetic to
 * calculate the return value.
 */
int *find_middle(int a[], int n)
{
    return a + (n / 2);
}
